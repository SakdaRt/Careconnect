import { useMemo, useState } from 'react';
import toast from 'react-hot-toast';
import { MainLayout } from '../../layouts';
import { Button, Card, Input } from '../../components/ui';
import { useAuth } from '../../contexts';

function roleLabel(role: string) {
  if (role === 'hirer') return 'ผู้ว่าจ้าง';
  if (role === 'caregiver') return 'ผู้ดูแล';
  return 'แอดมิน';
}

export default function ProfilePage() {
  const { user, updateUser, logout } = useAuth();
  const [name, setName] = useState(user?.name || '');
  const [saving, setSaving] = useState(false);

  const primaryId = useMemo(() => user?.email || user?.phone_number || '-', [user]);

  const handleSave = async () => {
    if (!user) return;
    setSaving(true);
    try {
      updateUser({ name: name.trim() || undefined });
      toast.success('บันทึกแล้ว');
    } finally {
      setSaving(false);
    }
  };

  return (
    <MainLayout showBottomBar={false}>
      <div className="max-w-3xl mx-auto px-4 py-6 space-y-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">โปรไฟล์</h1>
            <p className="text-sm text-gray-600">ข้อมูลบัญชีและสถานะการยืนยันตัวตน</p>
          </div>
          <Button variant="outline" onClick={logout} disabled={!user}>
            ออกจากระบบ
          </Button>
        </div>

        {!user ? (
          <Card className="p-6">
            <div className="text-sm text-gray-700">กรุณาเข้าสู่ระบบก่อน</div>
          </Card>
        ) : (
          <>
            <Card className="p-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input
                  label="ชื่อที่ใช้แสดง"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="ชื่อของคุณ"
                />
                <div className="flex flex-col gap-1">
                  <div className="text-sm font-semibold text-gray-700">บัญชี</div>
                  <div className="text-sm text-gray-900">{primaryId}</div>
                  <div className="text-xs text-gray-500 font-mono break-all">{user.id}</div>
                </div>
              </div>

              <div className="flex gap-3 mt-4">
                <Button variant="primary" loading={saving} onClick={handleSave}>
                  บันทึก
                </Button>
                <Button variant="outline" onClick={() => setName(user.name || '')}>
                  ยกเลิก
                </Button>
              </div>
            </Card>

            <Card className="p-6">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <div className="text-xs text-gray-500">บทบาท</div>
                  <div className="text-sm font-semibold text-gray-900">{roleLabel(user.role)}</div>
                </div>
                <div>
                  <div className="text-xs text-gray-500">Trust Level</div>
                  <div className="text-sm font-semibold text-gray-900">{user.trust_level}</div>
                </div>
                <div>
                  <div className="text-xs text-gray-500">งานสำเร็จ</div>
                  <div className="text-sm font-semibold text-gray-900">{user.completed_jobs_count}</div>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <div className="text-sm font-semibold text-gray-900 mb-3">การยืนยัน</div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="flex items-center justify-between gap-3">
                  <div className="text-sm text-gray-700">อีเมล</div>
                  <div className={`text-sm font-semibold ${user.is_email_verified ? 'text-green-700' : 'text-gray-500'}`}>
                    {user.is_email_verified ? 'ยืนยันแล้ว' : 'ยังไม่ยืนยัน'}
                  </div>
                </div>
                <div className="flex items-center justify-between gap-3">
                  <div className="text-sm text-gray-700">เบอร์โทร</div>
                  <div className={`text-sm font-semibold ${user.is_phone_verified ? 'text-green-700' : 'text-gray-500'}`}>
                    {user.is_phone_verified ? 'ยืนยันแล้ว' : 'ยังไม่ยืนยัน'}
                  </div>
                </div>
                <div className="flex items-center justify-between gap-3">
                  <div className="text-sm text-gray-700">2FA</div>
                  <div className={`text-sm font-semibold ${user.two_factor_enabled ? 'text-green-700' : 'text-gray-500'}`}>
                    {user.two_factor_enabled ? 'เปิดใช้งาน' : 'ปิดอยู่'}
                  </div>
                </div>
              </div>
              <div className="text-xs text-gray-500 mt-3">
                หน้านี้เป็น MVP; การแก้ไขโปรไฟล์เชิงลึกและ 2FA จะทำในเฟสถัดไป
              </div>
            </Card>
          </>
        )}
      </div>
    </MainLayout>
  );
}

