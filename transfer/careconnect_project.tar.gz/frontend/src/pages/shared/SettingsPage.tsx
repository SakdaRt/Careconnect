import { Link } from 'react-router-dom';
import toast from 'react-hot-toast';
import { MainLayout } from '../../layouts';
import { Button, Card } from '../../components/ui';
import { useAuth } from '../../contexts';
import { markAllAsRead } from '../../mocks';

function clearDemoData() {
  const keys = Object.keys(localStorage);
  for (const key of keys) {
    if (key.startsWith('careconnect_demo_') || key === 'careconnect_demo_platform_wallet_id') {
      localStorage.removeItem(key);
    }
  }
}

export default function SettingsPage() {
  const { user } = useAuth();

  return (
    <MainLayout showBottomBar={false}>
      <div className="max-w-3xl mx-auto px-4 py-6 space-y-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">ตั้งค่า / ช่วยเหลือ</h1>
          <p className="text-sm text-gray-600">การตั้งค่าพื้นฐานและลิงก์ช่วยเหลือ</p>
        </div>

        <Card className="p-6">
          <div className="text-sm font-semibold text-gray-900 mb-3">ช่วยเหลือ</div>
          <div className="flex flex-col sm:flex-row gap-2">
            <Link to="/faq">
              <Button variant="outline">คำถามที่พบบ่อย</Button>
            </Link>
            <Link to="/contact">
              <Button variant="outline">ติดต่อเรา</Button>
            </Link>
            <Link to="/about">
              <Button variant="outline">เกี่ยวกับเรา</Button>
            </Link>
          </div>
        </Card>

        <Card className="p-6">
          <div className="text-sm font-semibold text-gray-900 mb-3">การแจ้งเตือน</div>
          <div className="flex flex-col sm:flex-row gap-2">
            <Button
              variant="outline"
              disabled={!user}
              onClick={() => {
                if (!user) return;
                markAllAsRead(user.id);
                toast.success('ทำเครื่องหมายว่าอ่านทั้งหมดแล้ว');
              }}
            >
              อ่านการแจ้งเตือนทั้งหมด
            </Button>
            <Link to="/notifications">
              <Button variant="primary">ไปที่การแจ้งเตือน</Button>
            </Link>
          </div>
        </Card>

        <Card className="p-6">
          <div className="text-sm font-semibold text-gray-900 mb-3">เดโม / เครื่องมือ</div>
          <div className="flex flex-col sm:flex-row gap-2">
            <Button
              variant="danger"
              onClick={() => {
                const ok = window.confirm('ล้างข้อมูลเดโมในเบราว์เซอร์?');
                if (!ok) return;
                clearDemoData();
                toast.success('ล้างข้อมูลเดโมแล้ว');
              }}
            >
              ล้างข้อมูลเดโม
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                const ok = window.confirm('รีเฟรชหน้าเว็บ?');
                if (!ok) return;
                window.location.reload();
              }}
            >
              รีเฟรชหน้า
            </Button>
          </div>
          <div className="text-xs text-gray-500 mt-3">การตั้งค่าเชิงลึก (ภาษา/ธีม/ความเป็นส่วนตัว) จะเพิ่มในเฟสถัดไป</div>
        </Card>
      </div>
    </MainLayout>
  );
}

