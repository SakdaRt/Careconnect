import { Link, useNavigate } from 'react-router-dom';
import { useState } from 'react';
import { Phone, ArrowLeft, Shield } from 'lucide-react';
import { AuthLayout } from '../../layouts';
import { Button, PhoneInput, OTPInput, PasswordInput } from '../../components/ui';
import toast from 'react-hot-toast';

type Step = 'phone' | 'otp' | 'password';

export default function MemberRegisterPage() {
  const navigate = useNavigate();
  const [step, setStep] = useState<Step>('phone');
  const [formData, setFormData] = useState({
    phone: '',
    otp: '',
    password: '',
    confirmPassword: '',
  });
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  // Step 1: Phone submission
  const validatePhone = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.phone) {
      newErrors.phone = 'กรุณากรอกเบอร์โทรศัพท์';
    } else {
      const digits = formData.phone.replace(/\D/g, '');
      if (digits.length < 10) {
        newErrors.phone = 'เบอร์โทรศัพท์ไม่ถูกต้อง';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSendOTP = async () => {
    if (!validatePhone()) return;

    setLoading(true);
    try {
      // Mock API call - send OTP via SMS
      await new Promise((resolve) => setTimeout(resolve, 1500));

      toast.success('ส่งรหัส OTP ไปยังเบอร์โทรของคุณแล้ว');
      setStep('otp');
    } catch (error: any) {
      toast.error('เกิดข้อผิดพลาด กรุณาลองใหม่อีกครั้ง');
    } finally {
      setLoading(false);
    }
  };

  // Step 2: OTP verification
  const handleVerifyOTP = async () => {
    if (formData.otp.length !== 6) {
      setErrors({ otp: 'กรุณากรอกรหัส OTP ให้ครบ 6 หลัก' });
      return;
    }

    setLoading(true);
    try {
      // Mock API call - verify OTP
      await new Promise((resolve) => setTimeout(resolve, 1500));

      toast.success('ยืนยันเบอร์โทรสำเร็จ');
      setStep('password');
    } catch (error: any) {
      toast.error('รหัส OTP ไม่ถูกต้อง');
    } finally {
      setLoading(false);
    }
  };

  const handleResendOTP = async () => {
    setLoading(true);
    try {
      await new Promise((resolve) => setTimeout(resolve, 1500));
      toast.success('ส่งรหัส OTP ใหม่แล้ว');
      setFormData({ ...formData, otp: '' });
    } catch (error: any) {
      toast.error('เกิดข้อผิดพลาด');
    } finally {
      setLoading(false);
    }
  };

  // Step 3: Password creation
  const validatePassword = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.password) {
      newErrors.password = 'กรุณากรอกรหัสผ่าน';
    } else if (formData.password.length < 6) {
      newErrors.password = 'รหัสผ่านต้องมีอย่างน้อย 6 ตัวอักษร';
    }

    if (!formData.confirmPassword) {
      newErrors.confirmPassword = 'กรุณายืนยันรหัสผ่าน';
    } else if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = 'รหัสผ่านไม่ตรงกัน';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleCreateAccount = async () => {
    if (!validatePassword()) return;

    setLoading(true);
    try {
      // Mock API call - create account
      await new Promise((resolve) => setTimeout(resolve, 1500));

      toast.success('สร้างบัญชีสำเร็จ');
      // Navigate to role selection
      navigate('/register/role');
    } catch (error: any) {
      toast.error('เกิดข้อผิดพลาด กรุณาลองใหม่อีกครั้ง');
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthLayout>
      <div className="bg-white rounded-lg shadow-md p-8">
        <Link
          to="/register"
          className="inline-flex items-center text-gray-600 hover:text-gray-900 mb-6"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          <span className="text-sm">กลับ</span>
        </Link>

        <div className="flex items-center justify-center mb-6">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
            <Phone className="w-8 h-8 text-green-600" />
          </div>
        </div>

        <h1 className="text-3xl font-bold text-gray-900 text-center mb-2">
          สมัครบัญชีสมาชิก
        </h1>
        <p className="text-gray-600 text-center mb-8">ลงทะเบียนด้วยเบอร์โทรศัพท์</p>

        {/* Progress Steps */}
        <div className="flex items-center justify-center mb-8">
          <div className="flex items-center gap-2">
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold ${
                step === 'phone'
                  ? 'bg-green-600 text-white'
                  : 'bg-green-600 text-white'
              }`}
            >
              1
            </div>
            <div className="w-12 h-0.5 bg-gray-300">
              <div
                className={`h-full bg-green-600 transition-all ${
                  step !== 'phone' ? 'w-full' : 'w-0'
                }`}
              />
            </div>
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold ${
                step === 'otp'
                  ? 'bg-green-600 text-white'
                  : step === 'password'
                  ? 'bg-green-600 text-white'
                  : 'bg-gray-200 text-gray-600'
              }`}
            >
              2
            </div>
            <div className="w-12 h-0.5 bg-gray-300">
              <div
                className={`h-full bg-green-600 transition-all ${
                  step === 'password' ? 'w-full' : 'w-0'
                }`}
              />
            </div>
            <div
              className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold ${
                step === 'password'
                  ? 'bg-green-600 text-white'
                  : 'bg-gray-200 text-gray-600'
              }`}
            >
              3
            </div>
          </div>
        </div>

        {/* Step 1: Phone */}
        {step === 'phone' && (
          <div className="space-y-4">
            <PhoneInput
              label="เบอร์โทรศัพท์"
              placeholder="+66 8X XXXX XXXX"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              error={errors.phone}
              required
            />

            <Button
              variant="secondary"
              size="lg"
              fullWidth
              loading={loading}
              onClick={handleSendOTP}
            >
              ส่งรหัส OTP
            </Button>

            <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg">
              <p className="text-sm text-green-900">
                <strong>บัญชีสมาชิก:</strong> สามารถเป็นทั้งผู้ว่าจ้างและผู้ดูแลได้
                คุณจะเลือกบทบาทในขั้นตอนถัดไป
              </p>
            </div>
          </div>
        )}

        {/* Step 2: OTP */}
        {step === 'otp' && (
          <div className="space-y-4">
            <div className="text-center mb-6">
              <p className="text-gray-600">
                เราได้ส่งรหัส OTP ไปยัง
                <br />
                <span className="font-semibold text-gray-900">{formData.phone}</span>
              </p>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2 text-center">
                รหัส OTP <span className="text-red-500">*</span>
              </label>
              <OTPInput
                value={formData.otp}
                onChange={(value) => setFormData({ ...formData, otp: value })}
                error={errors.otp}
              />
            </div>

            <Button
              variant="secondary"
              size="lg"
              fullWidth
              loading={loading}
              onClick={handleVerifyOTP}
            >
              ยืนยันรหัส OTP
            </Button>

            <div className="text-center">
              <button
                onClick={handleResendOTP}
                disabled={loading}
                className="text-green-600 hover:text-green-700 text-sm"
              >
                ไม่ได้รับรหัส? ส่งใหม่อีกครั้ง
              </button>
            </div>
          </div>
        )}

        {/* Step 3: Password */}
        {step === 'password' && (
          <div className="space-y-4">
            <div className="flex items-center gap-3 p-4 bg-green-50 border border-green-200 rounded-lg mb-6">
              <Shield className="w-5 h-5 text-green-600" />
              <p className="text-sm text-green-900">
                <strong>เบอร์โทรยืนยันแล้ว:</strong> {formData.phone}
              </p>
            </div>

            <PasswordInput
              label="รหัสผ่าน"
              placeholder="กรอกรหัสผ่าน (อย่างน้อย 6 ตัวอักษร)"
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              error={errors.password}
              required
            />

            <PasswordInput
              label="ยืนยันรหัสผ่าน"
              placeholder="กรอกรหัสผ่านอีกครั้ง"
              value={formData.confirmPassword}
              onChange={(e) =>
                setFormData({ ...formData, confirmPassword: e.target.value })
              }
              error={errors.confirmPassword}
              required
            />

            <Button
              variant="secondary"
              size="lg"
              fullWidth
              loading={loading}
              onClick={handleCreateAccount}
            >
              สร้างบัญชี
            </Button>
          </div>
        )}

        {/* Already have account */}
        <div className="mt-8 pt-6 border-t border-gray-200 text-center">
          <p className="text-gray-600 mb-4">มีบัญชีอยู่แล้ว?</p>
          <Link to="/login">
            <Button variant="outline" fullWidth>
              เข้าสู่ระบบ
            </Button>
          </Link>
        </div>
      </div>
    </AuthLayout>
  );
}
