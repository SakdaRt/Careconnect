// Wallet Mock Data
export interface Wallet {
  user_id: string;
  available_balance: number;
  held_balance: number;
  total_earnings?: number; // For caregivers
  total_spent?: number; // For hirers
}

export interface Transaction {
  id: string;
  user_id: string;
  type: 'credit' | 'debit' | 'hold' | 'release' | 'capture';
  amount: number;
  description: string;
  reference_type: 'job' | 'topup' | 'withdrawal' | 'refund';
  reference_id: string;
  created_at: string;
}

export const mockWallets: Record<string, Wallet> = {
  'hirer-1': {
    user_id: 'hirer-1',
    available_balance: 5000,
    held_balance: 1900, // 400 (job-4) + 1500 (job-5)
    total_spent: 3500,
  },
  'caregiver-1': {
    user_id: 'caregiver-1',
    available_balance: 8000,
    held_balance: 1900, // 400 (job-4) + 1500 (job-5) in escrow
    total_earnings: 12400,
  },
  'hirer-2': {
    user_id: 'hirer-2',
    available_balance: 10000,
    held_balance: 0,
    total_spent: 0,
  },
};

export const mockTransactions: Transaction[] = [
  // Hirer-1 transactions
  {
    id: 'txn-1',
    user_id: 'hirer-1',
    type: 'credit',
    amount: 10000,
    description: 'เติมเงินเข้ากระเป๋า',
    reference_type: 'topup',
    reference_id: 'topup-1',
    created_at: '2026-01-05T10:00:00Z',
  },
  {
    id: 'txn-2',
    user_id: 'hirer-1',
    type: 'hold',
    amount: 400,
    description: 'กันเงินสำหรับงาน: ดูแลคุณยายเช้า',
    reference_type: 'job',
    reference_id: 'job-4',
    created_at: '2026-01-09T14:00:00Z',
  },
  {
    id: 'txn-3',
    user_id: 'hirer-1',
    type: 'hold',
    amount: 1500,
    description: 'กันเงินสำหรับงาน: ดูแลคุณยายวันนี้',
    reference_type: 'job',
    reference_id: 'job-5',
    created_at: '2026-01-09T06:00:00Z',
  },
  {
    id: 'txn-4',
    user_id: 'hirer-1',
    type: 'debit',
    amount: 400,
    description: 'จ่ายเงินงาน: ดูแลคุณยายเย็น (เสร็จแล้ว)',
    reference_type: 'job',
    reference_id: 'job-6',
    created_at: '2026-01-08T21:15:00Z',
  },

  // Caregiver-1 transactions
  {
    id: 'txn-5',
    user_id: 'caregiver-1',
    type: 'credit',
    amount: 400,
    description: 'รับเงินจากงาน: ดูแลคุณยายเย็น (เสร็จแล้ว)',
    reference_type: 'job',
    reference_id: 'job-6',
    created_at: '2026-01-08T21:15:00Z',
  },
  {
    id: 'txn-6',
    user_id: 'caregiver-1',
    type: 'credit',
    amount: 1200,
    description: 'รับเงินจากงาน: ดูแลคุณยาย (งานก่อนหน้า)',
    reference_type: 'job',
    reference_id: 'job-old-1',
    created_at: '2026-01-07T18:00:00Z',
  },
];

// Helper functions
export function getWalletByUserId(userId: string): Wallet | undefined {
  return mockWallets[userId];
}

export function getTransactionsByUserId(userId: string): Transaction[] {
  return mockTransactions.filter(txn => txn.user_id === userId);
}

export function addTransaction(transaction: Omit<Transaction, 'id' | 'created_at'>): Transaction {
  const newTransaction: Transaction = {
    ...transaction,
    id: `txn-${Date.now()}`,
    created_at: new Date().toISOString(),
  };

  mockTransactions.push(newTransaction);

  // Update wallet balance
  const wallet = mockWallets[transaction.user_id];
  if (wallet) {
    if (transaction.type === 'credit') {
      wallet.available_balance += transaction.amount;
    } else if (transaction.type === 'debit') {
      wallet.available_balance -= transaction.amount;
    } else if (transaction.type === 'hold') {
      wallet.available_balance -= transaction.amount;
      wallet.held_balance += transaction.amount;
    } else if (transaction.type === 'release') {
      wallet.held_balance -= transaction.amount;
      wallet.available_balance += transaction.amount;
    } else if (transaction.type === 'capture') {
      wallet.held_balance -= transaction.amount;
    }
  }

  return newTransaction;
}

export function topUpWallet(userId: string, amount: number): Transaction {
  return addTransaction({
    user_id: userId,
    type: 'credit',
    amount,
    description: 'เติมเงินเข้ากระเป๋า',
    reference_type: 'topup',
    reference_id: `topup-${Date.now()}`,
  });
}
