import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import api, { User } from '../services/api';

// Re-export types for backwards compatibility
export type UserRole = 'hirer' | 'caregiver' | 'admin';
export type AccountType = 'guest' | 'member';
export type TrustLevel = 'L0' | 'L1' | 'L2' | 'L3';
export type UserStatus = 'active' | 'suspended' | 'deleted';

export type { User };

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<void>;
  loginWithPhone: (phone: string, password: string) => Promise<void>;
  registerGuest: (email: string, password: string, role: UserRole) => Promise<void>;
  registerMember: (phone: string, password: string, role: UserRole) => Promise<void>;
  loginAsDemo: (role: Exclude<UserRole, 'admin'>) => void;
  logout: () => void;
  updateUser: (updates: Partial<User>) => void;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Check for stored user and validate token on mount
  useEffect(() => {
    const initAuth = async () => {
      const storedUser = localStorage.getItem('careconnect_user');
      const token = localStorage.getItem('careconnect_token');

      if (storedUser && token) {
        try {
          // Validate token by fetching current user
          const response = await api.getCurrentUser();
          if (response.success && response.data) {
            setUser(response.data.user);
            localStorage.setItem('careconnect_user', JSON.stringify(response.data.user));
          } else {
            // Token invalid, clear stored data
            api.clearTokens();
            setUser(null);
          }
        } catch (error) {
          console.error('Failed to validate auth token:', error);
          api.clearTokens();
          setUser(null);
        }
      }
      setIsLoading(false);
    };

    initAuth();
  }, []);

  // Save user to localStorage whenever it changes
  useEffect(() => {
    if (user) {
      localStorage.setItem('careconnect_user', JSON.stringify(user));
    }
  }, [user]);

  const login = async (email: string, password: string) => {
    setIsLoading(true);
    try {
      const response = await api.loginWithEmail(email, password);

      if (!response.success || !response.data) {
        throw new Error(response.error || 'Login failed');
      }

      setUser(response.data.user);
    } finally {
      setIsLoading(false);
    }
  };

  const loginWithPhone = async (phone: string, password: string) => {
    setIsLoading(true);
    try {
      const response = await api.loginWithPhone(phone, password);

      if (!response.success || !response.data) {
        throw new Error(response.error || 'Login failed');
      }

      setUser(response.data.user);
    } finally {
      setIsLoading(false);
    }
  };

  const registerGuest = async (email: string, password: string, role: UserRole) => {
    setIsLoading(true);
    try {
      const response = await api.registerGuest(email, password, role);

      if (!response.success || !response.data) {
        throw new Error(response.error || 'Registration failed');
      }

      setUser(response.data.user);
    } finally {
      setIsLoading(false);
    }
  };

  const registerMember = async (phone: string, password: string, role: UserRole) => {
    setIsLoading(true);
    try {
      const response = await api.registerMember(phone, password, role);

      if (!response.success || !response.data) {
        throw new Error(response.error || 'Registration failed');
      }

      setUser(response.data.user);
    } finally {
      setIsLoading(false);
    }
  };

  const loginAsDemo = (role: Exclude<UserRole, 'admin'>) => {
    const demoUser: User = {
      id: crypto.randomUUID(),
      email: role === 'hirer' ? 'hirer_demo@careconnect.local' : 'caregiver_demo@careconnect.local',
      phone_number: null,
      account_type: 'guest',
      role,
      status: 'active',
      trust_level: 'L1',
      trust_score: 0,
      is_email_verified: true,
      is_phone_verified: true,
      two_factor_enabled: false,
      completed_jobs_count: 0,
      first_job_waiver_used: false,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    localStorage.setItem('careconnect_token', 'demo');
    localStorage.setItem('careconnect_refresh_token', 'demo');
    localStorage.setItem('careconnect_user', JSON.stringify(demoUser));
    setUser(demoUser);
  };

  const logout = async () => {
    try {
      await api.logout();
    } catch (error) {
      console.error('Logout error:', error);
    }
    localStorage.removeItem('careconnect_user');
    setUser(null);
  };

  const updateUser = (updates: Partial<User>) => {
    if (user) {
      const updatedUser = { ...user, ...updates };
      setUser(updatedUser);
    }
  };

  const refreshUser = async () => {
    try {
      const response = await api.getCurrentUser();
      if (response.success && response.data) {
        setUser(response.data.user);
      }
    } catch (error) {
      console.error('Failed to refresh user:', error);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        login,
        loginWithPhone,
        registerGuest,
        registerMember,
        loginAsDemo,
        logout,
        updateUser,
        refreshUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
