import api, { BankAccount, ChatThread, JobPost, Paginated, TopupIntent, WalletBalance, WithdrawalRequest } from './api';
import { demoStore } from './demoStore';

type WalletRole = 'hirer' | 'caregiver';

const isDemoToken = () => localStorage.getItem('careconnect_token') === 'demo';
const getDemoUserId = () => {
  const raw = localStorage.getItem('careconnect_user');
  if (!raw) return 'demo-hirer';
  try {
    const parsed = JSON.parse(raw) as { id?: string };
    return parsed.id || 'demo-hirer';
  } catch {
    return 'demo-hirer';
  }
};

const toPaginated = <T>(items: T[], page = 1, limit = items.length): Paginated<T> => {
  const total = items.length;
  return { data: items, total, page, limit, totalPages: Math.max(1, Math.ceil(total / limit)) };
};
const ok = <T>(data: T) => ({ success: true, data, error: undefined as string | undefined });

export const appApi = {
  isDemoToken,

  async getJobFeed(filters?: {
    job_type?: string;
    risk_level?: string;
    is_urgent?: boolean;
    page?: number;
    limit?: number;
  }) {
    if (!isDemoToken()) return api.getJobFeed(filters);
    const items = demoStore.listJobFeed();
    const page = filters?.page || 1;
    const limit = filters?.limit || items.length || 20;
    return ok(toPaginated(items, page, limit));
  },

  async getMyJobs(hirerId: string, status?: string, page?: number, limit?: number) {
    if (!isDemoToken()) return api.getMyJobs(status, page, limit);
    const items = demoStore.listMyJobs(hirerId, status);
    return ok(toPaginated(items, page || 1, limit || items.length || 20));
  },

  async getAssignedJobs(caregiverId: string, status?: string, page?: number, limit?: number) {
    if (!isDemoToken()) return api.getAssignedJobs(status, page, limit);
    const items = demoStore.listCaregiverJobs(caregiverId, status as any);
    return ok(toPaginated(items, page || 1, limit || items.length || 20));
  },

  async getJobById(jobId: string) {
    if (!isDemoToken()) return api.getJobById(jobId);
    const job = demoStore.getJobById(jobId) || demoStore.getJobPostByJobId(jobId);
    return ok({ job: (job as JobPost | null) || null });
  },

  async createJob(hirerId: string, jobData: any) {
    if (!isDemoToken()) return api.createJob(jobData);
    const job = demoStore.createJob(hirerId, jobData);
    return ok({ job });
  },

  async publishJob(jobPostId: string, hirerId: string) {
    if (!isDemoToken()) return api.publishJob(jobPostId);
    const job = demoStore.publishJob(jobPostId, hirerId);
    if (!job) return { success: false, error: 'Publish failed' };
    return ok({ job });
  },

  async cancelJob(jobPostId: string, hirerId: string, reason?: string) {
    if (!isDemoToken()) return api.cancelJob(jobPostId, reason || '');
    const job = demoStore.cancelJob(jobPostId, hirerId);
    if (!job) return { success: false, error: 'Cancel failed' };
    if (reason) {
      demoStore.saveCancelReason(jobPostId, reason);
    }
    return ok({ job });
  },

  async acceptJob(jobPostId: string, caregiverId: string, message?: string) {
    if (!isDemoToken()) return api.acceptJob(jobPostId, message);
    const demo = demoStore.acceptJob(jobPostId, caregiverId);
    if (!demo) return { success: false, error: 'Accept failed' };
    return ok({
      job_id: demo.job_id,
      assignment_id: null,
      chat_thread_id: demo.chat_thread_id,
      escrow_amount: 0,
    });
  },

  async checkIn(jobId: string, caregiverId: string, gpsData?: { lat: number; lng: number; accuracy_m?: number }) {
    if (!isDemoToken()) return api.checkIn(jobId, gpsData);
    const job = demoStore.checkIn(jobId, caregiverId);
    if (!job) return { success: false, error: 'Check-in failed' };
    return ok({ job });
  },

  async checkOut(jobId: string, caregiverId: string, gpsData?: { lat: number; lng: number; accuracy_m?: number }) {
    if (!isDemoToken()) return api.checkOut(jobId, gpsData);
    const job = demoStore.checkOut(jobId, caregiverId);
    if (!job) return { success: false, error: 'Check-out failed' };
    return ok({ job });
  },

  async getChatThread(jobId: string) {
    if (!isDemoToken()) return api.getChatThread(jobId);
    const thread = demoStore.getThreadByJobId(jobId);
    return ok({ thread: (thread as ChatThread | null) || null });
  },

  async getOrCreateChatThread(jobId: string) {
    if (!isDemoToken()) return api.getOrCreateChatThread(jobId);
    const thread = demoStore.getThreadByJobId(jobId);
    if (!thread) return { success: false, error: 'Thread not found' };
    return ok({ thread });
  },

  async getChatMessages(threadId: string, limit?: number, before?: string) {
    if (!isDemoToken()) return api.getChatMessages(threadId, limit, before);
    const items = demoStore.getMessages(threadId);
    return ok(toPaginated(items, 1, limit || items.length || 50));
  },

  async sendMessage(threadId: string, sender: { id: string; role: string; name?: string }, content: string, messageType = 'text') {
    if (!isDemoToken()) return api.sendMessage(threadId, content, messageType);
    const message = demoStore.sendMessage(threadId, sender, content);
    return ok({ message });
  },

  async getDispute(disputeId: string) {
    if (!isDemoToken()) return api.getDispute(disputeId);
    const dispute = demoStore.getDisputeById(disputeId);
    if (!dispute) return { success: false, error: 'Dispute not found' };
    const messages = demoStore.getDisputeMessages(disputeId);
    const events = demoStore.getDisputeEvents(disputeId);
    return ok({ dispute, messages, events });
  },

  async getDisputeByJob(jobId: string) {
    if (!isDemoToken()) return api.getDisputeByJob(jobId);
    const dispute = demoStore.getDisputeByJob(jobId);
    return ok({ dispute: dispute || null });
  },

  async createDispute(jobId: string, openedByUserId: string, reason: string) {
    if (!isDemoToken()) return api.createDispute(jobId, reason);
    const dispute = demoStore.createDispute(jobId, openedByUserId, reason);
    if (!dispute) return { success: false, error: 'Create dispute failed' };
    return ok({ dispute });
  },

  async getCancelReason(jobIdOrJobPostId: string) {
    if (!isDemoToken()) {
      const res = await api.getJobById(jobIdOrJobPostId);
      const job = res.success ? (res.data as any)?.job : null;
      const reason = job && (job as any).cancel_reason ? String((job as any).cancel_reason) : '';
      return ok({ reason: reason || '' });
    }
    const jobPost = demoStore.getJobById(jobIdOrJobPostId) || demoStore.getJobPostByJobId(jobIdOrJobPostId);
    const reason = jobPost ? demoStore.getCancelReason(jobPost.id) : '';
    return ok({ reason });
  },

  async postDisputeMessage(
    disputeId: string,
    sender: { id: string; role?: string; email?: string },
    content: string
  ) {
    if (!isDemoToken()) return api.postDisputeMessage(disputeId, content);
    const message = demoStore.postDisputeMessage(disputeId, sender, content);
    if (!message) return { success: false, error: 'Post dispute message failed' };
    return ok({ message });
  },

  async requestDisputeClose(disputeId: string, actor: { id: string }, reason?: string) {
    if (!isDemoToken()) return api.requestDisputeClose(disputeId, reason);
    const okRes = demoStore.requestDisputeClose(disputeId, actor, reason);
    if (!okRes) return { success: false, error: 'Request dispute close failed' };
    return ok({ ok: okRes });
  },

  async getWalletBalance(userId: string, role: WalletRole) {
    if (!isDemoToken()) return api.getWallet();
    const wallet = demoStore.getWalletBalance(userId, role);
    return ok(wallet) as { success: boolean; data?: WalletBalance; error?: string };
  },

  async listWalletTransactions(userId: string, role: WalletRole, page = 1, limit = 20) {
    if (!isDemoToken()) return api.getWalletTransactions(page, limit);
    const wallet = demoStore.getWalletBalance(userId, role);
    const pageData = demoStore.listWalletTransactions(wallet.wallet_id, page, limit);
    return ok(toPaginated(pageData.data, page, limit));
  },

  async getWalletTransactionsPage(userId: string, role: WalletRole, page: number, limit: number) {
    if (!isDemoToken()) {
      const res = await api.getWalletTransactions(page, limit);
      return {
        items: res.success && res.data ? res.data.data : [],
        totalPages: res.success && res.data ? res.data.totalPages : 1,
      };
    }
    const wallet = demoStore.getWalletBalance(userId, role);
    const pageData = demoStore.listWalletTransactions(wallet.wallet_id, page, limit);
    return { items: pageData.data, totalPages: pageData.totalPages };
  },

  async topUpWallet(amount: number, paymentMethod: string) {
    if (!isDemoToken()) return api.topUpWallet(amount, paymentMethod);
    return { success: false, error: 'Topup not available in demo' };
  },

  async getPendingTopups() {
    if (!isDemoToken()) return api.getPendingTopups();
    return ok([] as TopupIntent[]);
  },

  async getTopupStatus(topupId: string) {
    if (!isDemoToken()) return api.getTopupStatus(topupId);
    return { success: false, error: 'Topup not available in demo' };
  },

  async getBankAccounts() {
    if (!isDemoToken()) return api.getBankAccounts();
    return ok([] as BankAccount[]);
  },

  async addBankAccount(input: {
    bank_code: string;
    bank_name?: string;
    account_number: string;
    account_name: string;
    set_primary?: boolean;
  }) {
    if (!isDemoToken()) return api.addBankAccount(input);
    return { success: false, error: 'Bank account not available in demo' };
  },

  async initiateWithdrawal(amount: number, bankAccountId: string) {
    if (!isDemoToken()) return api.initiateWithdrawal(amount, bankAccountId);
    return { success: false, error: 'Withdrawal not available in demo' };
  },

  async getWithdrawals(options?: { page?: number; limit?: number; status?: string }) {
    if (!isDemoToken()) return api.getWithdrawals(options);
    const page = options?.page || 1;
    const limit = options?.limit || 10;
    return ok(toPaginated([] as WithdrawalRequest[], page, limit));
  },

  async cancelWithdrawal(withdrawalId: string) {
    if (!isDemoToken()) return api.cancelWithdrawal(withdrawalId);
    return { success: false, error: 'Withdrawal not available in demo' };
  },

  async getCareRecipients() {
    if (!isDemoToken()) return api.getCareRecipients();
    return ok(demoStore.listCareRecipients(getDemoUserId()));
  },

  async getCareRecipient(id: string) {
    if (!isDemoToken()) return api.getCareRecipient(id);
    const item = demoStore.getCareRecipient(id);
    if (!item) return { success: false, error: 'Care recipient not found' };
    return ok(item);
  },

  async createCareRecipient(payload: any) {
    if (!isDemoToken()) return api.createCareRecipient(payload);
    const created = demoStore.createCareRecipient(getDemoUserId(), payload);
    return ok(created);
  },

  async updateCareRecipient(id: string, payload: any) {
    if (!isDemoToken()) return api.updateCareRecipient(id, payload);
    const updated = demoStore.updateCareRecipient(id, payload);
    if (!updated) return { success: false, error: 'Care recipient not found' };
    return ok(updated);
  },

  async deactivateCareRecipient(id: string) {
    if (!isDemoToken()) return api.deactivateCareRecipient(id);
    const updated = demoStore.deactivateCareRecipient(id);
    if (!updated) return { success: false, error: 'Care recipient not found' };
    return ok(updated);
  },
};
