import type {
  AdminDisputeEvent,
  CareRecipient,
  ChatMessage,
  ChatThread,
  CreateJobData,
  DisputeMessage,
  JobPost,
  Transaction,
  WalletBalance,
} from './api';

const JOB_POSTS_KEY = 'careconnect_demo_job_posts';
const JOBS_KEY = 'careconnect_demo_jobs';
const CHAT_THREADS_KEY = 'careconnect_demo_chat_threads';
const CHAT_MESSAGES_KEY = 'careconnect_demo_chat_messages';
const CARE_RECIPIENTS_KEY = 'careconnect_demo_care_recipients';
const WALLET_BALANCES_KEY = 'careconnect_demo_wallet_balances';
const WALLET_TRANSACTIONS_KEY = 'careconnect_demo_wallet_transactions';
const JOB_ESCROWS_KEY = 'careconnect_demo_job_escrows';
const PLATFORM_WALLET_ID_KEY = 'careconnect_demo_platform_wallet_id';
const DISPUTES_KEY = 'careconnect_demo_disputes';
const DISPUTE_EVENTS_KEY = 'careconnect_demo_dispute_events';
const DISPUTE_MESSAGES_KEY = 'careconnect_demo_dispute_messages';
const CANCEL_REASONS_KEY = 'careconnect_demo_cancel_reasons';

function readJobPosts(): JobPost[] {
  const raw = localStorage.getItem(JOB_POSTS_KEY);
  if (!raw) return [];
  try {
    return JSON.parse(raw) as JobPost[];
  } catch {
    return [];
  }
}

function writeJobPosts(jobPosts: JobPost[]) {
  localStorage.setItem(JOB_POSTS_KEY, JSON.stringify(jobPosts));
}

function readCareRecipients(): CareRecipient[] {
  const raw = localStorage.getItem(CARE_RECIPIENTS_KEY);
  if (!raw) return [];
  try {
    return JSON.parse(raw) as CareRecipient[];
  } catch {
    return [];
  }
}

function writeCareRecipients(items: CareRecipient[]) {
  localStorage.setItem(CARE_RECIPIENTS_KEY, JSON.stringify(items));
}

function createDefaultCareRecipients(hirerId: string) {
  const now = new Date().toISOString();
  const first: CareRecipient = {
    id: crypto.randomUUID(),
    hirer_id: hirerId,
    patient_display_name: 'คุณยายบุญช่วย',
    age_band: '75_89',
    gender: 'female',
    mobility_level: 'walk_assisted',
    communication_style: 'hearing_impaired',
    cognitive_status: 'mild_impairment',
    general_health_summary: 'เดินได้แต่ต้องพยุงเล็กน้อย มีอาการหลงลืมบางครั้ง',
    chronic_conditions_flags: ['hypertension'],
    symptoms_flags: ['shortness_of_breath'],
    medical_devices_flags: null,
    care_needs_flags: ['medication_reminder', 'transfer_assist'],
    behavior_risks_flags: ['fall_risk'],
    allergies_flags: null,
    is_active: true,
    created_at: now,
    updated_at: now,
  };
  const second: CareRecipient = {
    id: crypto.randomUUID(),
    hirer_id: hirerId,
    patient_display_name: 'คุณพ่อสมชาย',
    age_band: '60_74',
    gender: 'male',
    mobility_level: 'walk_independent',
    communication_style: 'normal',
    cognitive_status: 'normal',
    general_health_summary: 'ช่วยเหลือตัวเองได้ ต้องคุมอาหารและช่วยดูแลการกินยา',
    chronic_conditions_flags: ['diabetes'],
    symptoms_flags: null,
    medical_devices_flags: null,
    care_needs_flags: ['feeding', 'medication_reminder'],
    behavior_risks_flags: null,
    allergies_flags: ['food_allergy'],
    is_active: true,
    created_at: now,
    updated_at: now,
  };
  const items = [first, second];
  writeCareRecipients(items);
  return items;
}

type DemoJob = {
  id: string;
  job_post_id: string;
  hirer_id: string;
  caregiver_id: string;
  status: 'assigned' | 'in_progress' | 'completed' | 'cancelled';
  created_at: string;
  updated_at: string;
  assigned_at?: string;
  started_at?: string | null;
  completed_at?: string | null;
};

function readJobs(): DemoJob[] {
  const raw = localStorage.getItem(JOBS_KEY);
  if (!raw) return [];
  try {
    return JSON.parse(raw) as DemoJob[];
  } catch {
    return [];
  }
}

function writeJobs(jobs: DemoJob[]) {
  localStorage.setItem(JOBS_KEY, JSON.stringify(jobs));
}

function readThreads(): ChatThread[] {
  const raw = localStorage.getItem(CHAT_THREADS_KEY);
  if (!raw) return [];
  try {
    return JSON.parse(raw) as ChatThread[];
  } catch {
    return [];
  }
}

function writeThreads(threads: ChatThread[]) {
  localStorage.setItem(CHAT_THREADS_KEY, JSON.stringify(threads));
}

function readMessagesByThread(): Record<string, ChatMessage[]> {
  const raw = localStorage.getItem(CHAT_MESSAGES_KEY);
  if (!raw) return {};
  try {
    return JSON.parse(raw) as Record<string, ChatMessage[]>;
  } catch {
    return {};
  }
}

function writeMessagesByThread(messages: Record<string, ChatMessage[]>) {
  localStorage.setItem(CHAT_MESSAGES_KEY, JSON.stringify(messages));
}

function readCancelReasons(): Record<string, string> {
  const raw = localStorage.getItem(CANCEL_REASONS_KEY);
  if (!raw) return {};
  try {
    return JSON.parse(raw) as Record<string, string>;
  } catch {
    return {};
  }
}

function writeCancelReasons(map: Record<string, string>) {
  localStorage.setItem(CANCEL_REASONS_KEY, JSON.stringify(map));
}

type DemoDispute = {
  id: string;
  job_post_id: string;
  job_id: string | null;
  opened_by_user_id: string;
  status: 'open' | 'in_review' | 'resolved' | 'rejected';
  reason: string;
  assigned_admin_id: string | null;
  created_at: string;
  updated_at: string;
};

function readDisputes(): Record<string, DemoDispute> {
  const raw = localStorage.getItem(DISPUTES_KEY);
  if (!raw) return {};
  try {
    return JSON.parse(raw) as Record<string, DemoDispute>;
  } catch {
    return {};
  }
}

function writeDisputes(map: Record<string, DemoDispute>) {
  localStorage.setItem(DISPUTES_KEY, JSON.stringify(map));
}

function readDisputeEvents(): Record<string, AdminDisputeEvent[]> {
  const raw = localStorage.getItem(DISPUTE_EVENTS_KEY);
  if (!raw) return {};
  try {
    return JSON.parse(raw) as Record<string, AdminDisputeEvent[]>;
  } catch {
    return {};
  }
}

function writeDisputeEvents(map: Record<string, AdminDisputeEvent[]>) {
  localStorage.setItem(DISPUTE_EVENTS_KEY, JSON.stringify(map));
}

function readDisputeMessages(): Record<string, DisputeMessage[]> {
  const raw = localStorage.getItem(DISPUTE_MESSAGES_KEY);
  if (!raw) return {};
  try {
    return JSON.parse(raw) as Record<string, DisputeMessage[]>;
  } catch {
    return {};
  }
}

function writeDisputeMessages(map: Record<string, DisputeMessage[]>) {
  localStorage.setItem(DISPUTE_MESSAGES_KEY, JSON.stringify(map));
}

type WalletKey = `${'hirer' | 'caregiver'}:${string}`;

function readWalletBalances(): Record<WalletKey, WalletBalance> {
  const raw = localStorage.getItem(WALLET_BALANCES_KEY);
  if (!raw) return {} as Record<WalletKey, WalletBalance>;
  try {
    return JSON.parse(raw) as Record<WalletKey, WalletBalance>;
  } catch {
    return {} as Record<WalletKey, WalletBalance>;
  }
}

function writeWalletBalances(balances: Record<WalletKey, WalletBalance>) {
  localStorage.setItem(WALLET_BALANCES_KEY, JSON.stringify(balances));
}

function readWalletTransactions(): Record<string, Transaction[]> {
  const raw = localStorage.getItem(WALLET_TRANSACTIONS_KEY);
  if (!raw) return {};
  try {
    return JSON.parse(raw) as Record<string, Transaction[]>;
  } catch {
    return {};
  }
}

function writeWalletTransactions(map: Record<string, Transaction[]>) {
  localStorage.setItem(WALLET_TRANSACTIONS_KEY, JSON.stringify(map));
}

type DemoJobEscrow = {
  escrow_wallet_id: string;
  job_id: string;
  hirer_wallet_id: string;
  amount_total: number;
  amount_job: number;
  amount_fee: number;
  created_at: string;
};

function readJobEscrows(): Record<string, DemoJobEscrow> {
  const raw = localStorage.getItem(JOB_ESCROWS_KEY);
  if (!raw) return {};
  try {
    return JSON.parse(raw) as Record<string, DemoJobEscrow>;
  } catch {
    return {};
  }
}

function writeJobEscrows(map: Record<string, DemoJobEscrow>) {
  localStorage.setItem(JOB_ESCROWS_KEY, JSON.stringify(map));
}

function getPlatformWalletId() {
  const existing = localStorage.getItem(PLATFORM_WALLET_ID_KEY);
  if (existing) return existing;
  const created = crypto.randomUUID();
  localStorage.setItem(PLATFORM_WALLET_ID_KEY, created);
  return created;
}

export const demoStore = {
  getJobInstanceById(jobId: string) {
    return readJobs().find((j) => j.id === jobId) || null;
  },

  getJobById(jobPostId: string) {
    return readJobPosts().find((j) => j.id === jobPostId) || null;
  },

  getJobPostByJobId(jobId: string) {
    const job = readJobs().find((j) => j.id === jobId);
    if (!job) return null;
    return readJobPosts().find((p) => p.id === job.job_post_id) || null;
  },

  listMyJobs(hirerId: string, status?: string) {
    const all = readJobPosts().filter((j) => j.hirer_id === hirerId);
    const filtered = status ? all.filter((j) => j.status === status) : all;
    return filtered.sort((a, b) => (b.created_at || '').localeCompare(a.created_at || ''));
  },

  listCareRecipients(hirerId?: string) {
    let items = readCareRecipients();
    if (items.length === 0 && hirerId) {
      items = createDefaultCareRecipients(hirerId);
    }
    const filtered = hirerId ? items.filter((p) => p.hirer_id === hirerId) : items;
    return filtered.sort((a, b) => (b.updated_at || '').localeCompare(a.updated_at || ''));
  },

  getCareRecipient(id: string) {
    return readCareRecipients().find((p) => p.id === id) || null;
  },

  createCareRecipient(hirerId: string, payload: any) {
    const now = new Date().toISOString();
    const patientDisplayName = String(payload?.patient_display_name || '').trim() || 'ผู้รับการดูแล';
    const item: CareRecipient = {
      id: crypto.randomUUID(),
      hirer_id: hirerId,
      patient_display_name: patientDisplayName,
      age_band: payload?.age_band ?? null,
      gender: payload?.gender ?? null,
      mobility_level: payload?.mobility_level ?? null,
      communication_style: payload?.communication_style ?? null,
      cognitive_status: payload?.cognitive_status ?? null,
      general_health_summary: payload?.general_health_summary ?? null,
      chronic_conditions_flags: payload?.chronic_conditions_flags ?? null,
      symptoms_flags: payload?.symptoms_flags ?? null,
      medical_devices_flags: payload?.medical_devices_flags ?? null,
      care_needs_flags: payload?.care_needs_flags ?? null,
      behavior_risks_flags: payload?.behavior_risks_flags ?? null,
      allergies_flags: payload?.allergies_flags ?? null,
      is_active: true,
      created_at: now,
      updated_at: now,
    };
    const next = [item, ...readCareRecipients()];
    writeCareRecipients(next);
    return item;
  },

  updateCareRecipient(id: string, payload: any) {
    const items = readCareRecipients();
    const idx = items.findIndex((p) => p.id === id);
    if (idx < 0) return null;
    const current = items[idx];
    const withValue = (key: string, fallback: any) =>
      Object.prototype.hasOwnProperty.call(payload || {}, key) ? payload[key] : fallback;
    const updated: CareRecipient = {
      ...current,
      patient_display_name: withValue('patient_display_name', current.patient_display_name),
      age_band: withValue('age_band', current.age_band),
      gender: withValue('gender', current.gender),
      mobility_level: withValue('mobility_level', current.mobility_level),
      communication_style: withValue('communication_style', current.communication_style),
      cognitive_status: withValue('cognitive_status', current.cognitive_status ?? null),
      general_health_summary: withValue('general_health_summary', current.general_health_summary),
      chronic_conditions_flags: withValue('chronic_conditions_flags', current.chronic_conditions_flags ?? null),
      symptoms_flags: withValue('symptoms_flags', current.symptoms_flags ?? null),
      medical_devices_flags: withValue('medical_devices_flags', current.medical_devices_flags ?? null),
      care_needs_flags: withValue('care_needs_flags', current.care_needs_flags ?? null),
      behavior_risks_flags: withValue('behavior_risks_flags', current.behavior_risks_flags ?? null),
      allergies_flags: withValue('allergies_flags', current.allergies_flags ?? null),
      updated_at: new Date().toISOString(),
    };
    items[idx] = updated;
    writeCareRecipients(items);
    return updated;
  },

  deactivateCareRecipient(id: string) {
    const items = readCareRecipients();
    const idx = items.findIndex((p) => p.id === id);
    if (idx < 0) return null;
    const current = items[idx];
    const updated: CareRecipient = {
      ...current,
      is_active: false,
      updated_at: new Date().toISOString(),
    };
    items[idx] = updated;
    writeCareRecipients(items);
    return updated;
  },

  createJob(hirerId: string, jobData: CreateJobData) {
    const now = new Date().toISOString();
    const total_amount = Math.round(jobData.hourly_rate * jobData.total_hours);
    const platform_fee_percent = 10;
    const platform_fee_amount = Math.round(total_amount * (platform_fee_percent / 100));

    const jobPost: JobPost = {
      id: crypto.randomUUID(),
      hirer_id: hirerId,
      title: jobData.title,
      description: jobData.description,
      job_type: jobData.job_type,
      risk_level: jobData.risk_level || 'low_risk',
      status: 'draft',
      scheduled_start_at: jobData.scheduled_start_at,
      scheduled_end_at: jobData.scheduled_end_at,
      address_line1: jobData.address_line1,
      address_line2: jobData.address_line2 || null,
      district: jobData.district || null,
      province: jobData.province || null,
      postal_code: jobData.postal_code || null,
      lat: jobData.lat ?? null,
      lng: jobData.lng ?? null,
      geofence_radius_m: jobData.geofence_radius_m ?? 100,
      hourly_rate: jobData.hourly_rate,
      total_hours: jobData.total_hours,
      total_amount,
      platform_fee_percent,
      platform_fee_amount,
      min_trust_level: jobData.min_trust_level || 'L1',
      required_certifications: jobData.required_certifications || [],
      is_urgent: jobData.is_urgent || false,
      created_at: now,
      updated_at: now,
      posted_at: null,
    };

    const next = [jobPost, ...readJobPosts()];
    writeJobPosts(next);
    return jobPost;
  },

  publishJob(jobPostId: string, hirerId: string) {
    const all = readJobPosts();
    const idx = all.findIndex((j) => j.id === jobPostId && j.hirer_id === hirerId);
    if (idx < 0) return null;
    const job = all[idx];
    const updated: JobPost = {
      ...job,
      status: 'posted',
      posted_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    all[idx] = updated;
    writeJobPosts(all);
    return updated;
  },

  cancelJob(jobPostId: string, hirerId: string) {
    const jobInstance = readJobs().find((j) => j.id === jobPostId) || null;
    const resolvedJobPostId = jobInstance?.job_post_id || jobPostId;
    const resolvedHirerId = jobInstance?.hirer_id || hirerId;
    const all = readJobPosts();
    const idx = all.findIndex((j) => j.id === resolvedJobPostId && j.hirer_id === resolvedHirerId);
    if (idx < 0) return null;
    const job = all[idx];
    const now = new Date().toISOString();
    const updated: JobPost = {
      ...job,
      status: 'cancelled',
      updated_at: now,
    };
    all[idx] = updated;
    writeJobPosts(all);
    const jobs = readJobs();
    const updatedJobs: DemoJob[] = jobs.map((j) =>
      j.job_post_id === resolvedJobPostId && j.status !== 'completed'
        ? { ...j, status: 'cancelled', updated_at: now }
        : j
    );
    writeJobs(updatedJobs);
    return updated;
  },

  saveCancelReason(jobPostId: string, reason: string) {
    const map = readCancelReasons();
    map[jobPostId] = reason;
    writeCancelReasons(map);
  },

  getCancelReason(jobPostId: string) {
    const map = readCancelReasons();
    return map[jobPostId] || '';
  },

  listJobFeed() {
    return readJobPosts()
      .filter((j) => j.status === 'posted')
      .sort((a, b) => {
        if (a.is_urgent !== b.is_urgent) return a.is_urgent ? -1 : 1;
        return a.scheduled_start_at.localeCompare(b.scheduled_start_at);
      });
  },

  acceptJob(jobPostId: string, caregiverId: string) {
    const allPosts = readJobPosts();
    const postIdx = allPosts.findIndex((j) => j.id === jobPostId);
    if (postIdx < 0) return null;
    const post = allPosts[postIdx];
    if (post.status !== 'posted') return null;

    const now = new Date().toISOString();
    const jobId = crypto.randomUUID();
    const threadId = crypto.randomUUID();
    const escrowWalletId = crypto.randomUUID();

    const updatedPost: JobPost = {
      ...post,
      status: 'assigned',
      updated_at: now,
    };
    allPosts[postIdx] = updatedPost;
    writeJobPosts(allPosts);

    const jobs = readJobs();
    const job: DemoJob = {
      id: jobId,
      job_post_id: post.id,
      hirer_id: post.hirer_id,
      caregiver_id: caregiverId,
      status: 'assigned',
      created_at: now,
      updated_at: now,
      assigned_at: now,
      started_at: null,
      completed_at: null,
    };
    writeJobs([job, ...jobs]);

    const hirerWallet = this.getWalletBalance(post.hirer_id, 'hirer');
    const totalAmount = Number(post.total_amount || 0) + Number(post.platform_fee_amount || 0);
    if (hirerWallet.available_balance < totalAmount) {
      return null;
    }

    const balances = readWalletBalances();
    const hirerKey = `hirer:${post.hirer_id}` as WalletKey;
    const updatedHirerWallet = {
      ...hirerWallet,
      available_balance: hirerWallet.available_balance - totalAmount,
      held_balance: hirerWallet.held_balance,
      total_balance: hirerWallet.total_balance - totalAmount,
    } as WalletBalance;
    balances[hirerKey] = updatedHirerWallet;
    writeWalletBalances(balances);

    const escrows = readJobEscrows();
    escrows[jobId] = {
      escrow_wallet_id: escrowWalletId,
      job_id: jobId,
      hirer_wallet_id: hirerWallet.wallet_id,
      amount_total: totalAmount,
      amount_job: Number(post.total_amount || 0),
      amount_fee: Number(post.platform_fee_amount || 0),
      created_at: now,
    };
    writeJobEscrows(escrows);

    const txHold: Transaction = {
      id: crypto.randomUUID(),
      amount: totalAmount,
      currency: 'THB',
      from_wallet_id: hirerWallet.wallet_id,
      to_wallet_id: escrowWalletId,
      type: 'hold',
      reference_type: 'job',
      reference_id: jobId,
      provider_name: 'demo',
      provider_transaction_id: null,
      description: 'Job escrow hold (demo)',
      metadata: { job_id: jobId },
      created_at: now,
    };
    const txMap = readWalletTransactions();
    txMap[hirerWallet.wallet_id] = [txHold, ...(txMap[hirerWallet.wallet_id] || [])];
    writeWalletTransactions(txMap);

    const threads = readThreads();
    const thread: ChatThread = {
      id: threadId,
      job_id: jobId,
      status: 'open',
      created_at: now,
    };
    writeThreads([thread, ...threads]);

    const messagesByThread = readMessagesByThread();
    const systemMessage: ChatMessage = {
      id: crypto.randomUUID(),
      thread_id: threadId,
      sender_id: null,
      content: 'เริ่มห้องแชทสำหรับงานนี้แล้ว',
      type: 'text',
      created_at: now,
      sender_name: 'System',
      sender_role: null,
    };
    messagesByThread[threadId] = [systemMessage];
    writeMessagesByThread(messagesByThread);

    return { job_id: jobId, chat_thread_id: threadId };
  },

  listCaregiverJobs(caregiverId: string, status?: DemoJob['status']) {
    const jobs = readJobs().filter((j) => j.caregiver_id === caregiverId);
    const filtered = status ? jobs.filter((j) => j.status === status) : jobs;

    const byPostId = new Map(readJobPosts().map((p) => [p.id, p]));

    return filtered
      .map((j) => {
        const post = byPostId.get(j.job_post_id);
        return {
          id: j.id,
          job_post_id: j.job_post_id,
          hirer_id: j.hirer_id,
          status: j.status,
          assigned_at: j.assigned_at || null,
          started_at: j.started_at || null,
          completed_at: j.completed_at || null,
          cancelled_at: null,
          expired_at: null,
          job_closed_at: null,
          created_at: j.created_at,
          updated_at: j.updated_at,
          title: post?.title || 'งาน',
          description: post?.description || '',
          hourly_rate: post?.hourly_rate || 0,
          total_amount: post?.total_amount || 0,
          scheduled_start_at: post?.scheduled_start_at || new Date().toISOString(),
          scheduled_end_at: post?.scheduled_end_at || new Date().toISOString(),
          address_line1: post?.address_line1 || '',
          district: post?.district || null,
          province: post?.province || null,
        };
      })
      .sort((a, b) => (b.updated_at || '').localeCompare(a.updated_at || ''));
  },

  checkIn(jobId: string, caregiverId: string) {
    const all = readJobs();
    const idx = all.findIndex((j) => j.id === jobId && j.caregiver_id === caregiverId);
    if (idx < 0) return null;
    const job = all[idx];
    if (job.status !== 'assigned') return null;
    const now = new Date().toISOString();
    const updated: DemoJob = { ...job, status: 'in_progress', started_at: now, updated_at: now };
    all[idx] = updated;
    writeJobs(all);
    return updated;
  },

  checkOut(jobId: string, caregiverId: string) {
    const all = readJobs();
    const idx = all.findIndex((j) => j.id === jobId && j.caregiver_id === caregiverId);
    if (idx < 0) return null;
    const job = all[idx];
    if (job.status !== 'in_progress') return null;
    const now = new Date().toISOString();
    const updated: DemoJob = { ...job, status: 'completed', completed_at: now, updated_at: now };
    all[idx] = updated;
    writeJobs(all);

    const escrows = readJobEscrows();
    const escrow = escrows[jobId];
    if (escrow) {
      const caregiverWallet = this.getWalletBalance(caregiverId, 'caregiver');
      const balances = readWalletBalances();
      const caregiverKey = `caregiver:${caregiverId}` as WalletKey;
      balances[caregiverKey] = {
        ...caregiverWallet,
        available_balance: caregiverWallet.available_balance + escrow.amount_job,
        total_balance: caregiverWallet.total_balance + escrow.amount_job,
      };
      writeWalletBalances(balances);

      const txMap = readWalletTransactions();
      const txCaregiver: Transaction = {
        id: crypto.randomUUID(),
        amount: escrow.amount_job,
        currency: 'THB',
        from_wallet_id: escrow.escrow_wallet_id,
        to_wallet_id: caregiverWallet.wallet_id,
        type: 'release',
        reference_type: 'job',
        reference_id: jobId,
        provider_name: 'demo',
        provider_transaction_id: null,
        description: 'Payment for completed job (demo)',
        metadata: { job_id: jobId },
        created_at: now,
      };
      txMap[caregiverWallet.wallet_id] = [txCaregiver, ...(txMap[caregiverWallet.wallet_id] || [])];

      if (escrow.amount_fee > 0) {
        const platformWalletId = getPlatformWalletId();
        const txFee: Transaction = {
          id: crypto.randomUUID(),
          amount: escrow.amount_fee,
          currency: 'THB',
          from_wallet_id: escrow.escrow_wallet_id,
          to_wallet_id: platformWalletId,
          type: 'debit',
          reference_type: 'fee',
          reference_id: jobId,
          provider_name: 'demo',
          provider_transaction_id: null,
          description: 'Platform service fee (demo)',
          metadata: { job_id: jobId },
          created_at: now,
        };
        txMap[platformWalletId] = [txFee, ...(txMap[platformWalletId] || [])];
      }

      writeWalletTransactions(txMap);

      delete escrows[jobId];
      writeJobEscrows(escrows);
    }
    return updated;
  },

  getThreadByJobId(jobId: string) {
    return readThreads().find((t) => t.job_id === jobId) || null;
  },

  getMessages(threadId: string) {
    const map = readMessagesByThread();
    return map[threadId] || [];
  },

  sendMessage(threadId: string, sender: { id: string; role: string; name?: string }, content: string) {
    const now = new Date().toISOString();
    const message: ChatMessage = {
      id: crypto.randomUUID(),
      thread_id: threadId,
      sender_id: sender.id,
      content,
      type: 'text',
      created_at: now,
      sender_name: sender.name || sender.role,
      sender_role: sender.role,
    };

    const map = readMessagesByThread();
    const list = map[threadId] || [];
    map[threadId] = [...list, message];
    writeMessagesByThread(map);
    return message;
  },

  getWalletBalance(userId: string, walletType: 'hirer' | 'caregiver') {
    const balances = readWalletBalances();
    const key = `${walletType}:${userId}` as WalletKey;
    const existing = balances[key];
    if (existing) return existing;

    const created: WalletBalance = {
      wallet_id: crypto.randomUUID(),
      wallet_type: walletType,
      currency: 'THB',
      available_balance: 0,
      held_balance: 0,
      total_balance: 0,
    };
    balances[key] = created;
    writeWalletBalances(balances);
    return created;
  },

  listWalletTransactions(walletId: string, page = 1, limit = 20) {
    const map = readWalletTransactions();
    const all = map[walletId] || [];
    const start = (page - 1) * limit;
    const data = all.slice(start, start + limit);
    const total = all.length;
    return { data, total, page, limit, totalPages: Math.max(1, Math.ceil(total / limit)) };
  },

  topUpWallet(userId: string, amount: number) {
    const wallet = this.getWalletBalance(userId, 'hirer');
    const next: WalletBalance = {
      ...wallet,
      available_balance: wallet.available_balance + amount,
      total_balance: wallet.total_balance + amount,
    };

    const balances = readWalletBalances();
    const key = `hirer:${userId}` as WalletKey;
    balances[key] = next;
    writeWalletBalances(balances);

    const tx: Transaction = {
      id: crypto.randomUUID(),
      amount,
      currency: 'THB',
      from_wallet_id: null,
      to_wallet_id: wallet.wallet_id,
      type: 'credit',
      reference_type: 'topup',
      reference_id: crypto.randomUUID(),
      provider_name: 'demo',
      provider_transaction_id: null,
      description: 'Top-up (demo)',
      metadata: {},
      created_at: new Date().toISOString(),
    };

    const map = readWalletTransactions();
    map[wallet.wallet_id] = [tx, ...(map[wallet.wallet_id] || [])];
    writeWalletTransactions(map);
    return { wallet: next, transaction: tx };
  },

  withdrawWallet(userId: string, amount: number) {
    const wallet = this.getWalletBalance(userId, 'caregiver');
    if (wallet.available_balance < amount) return null;

    const next: WalletBalance = {
      ...wallet,
      available_balance: wallet.available_balance - amount,
      total_balance: wallet.total_balance - amount,
    };

    const balances = readWalletBalances();
    const key = `caregiver:${userId}` as WalletKey;
    balances[key] = next;
    writeWalletBalances(balances);

    const tx: Transaction = {
      id: crypto.randomUUID(),
      amount,
      currency: 'THB',
      from_wallet_id: wallet.wallet_id,
      to_wallet_id: null,
      type: 'debit',
      reference_type: 'withdrawal',
      reference_id: crypto.randomUUID(),
      provider_name: 'demo',
      provider_transaction_id: null,
      description: 'Withdrawal (demo)',
      metadata: {},
      created_at: new Date().toISOString(),
    };

    const map = readWalletTransactions();
    map[wallet.wallet_id] = [tx, ...(map[wallet.wallet_id] || [])];
    writeWalletTransactions(map);
    return { wallet: next, transaction: tx };
  },

  createDispute(jobIdOrJobPostId: string, openedByUserId: string, reason: string) {
    const now = new Date().toISOString();
    const jobPost = this.getJobById(jobIdOrJobPostId) || this.getJobPostByJobId(jobIdOrJobPostId);
    if (!jobPost) return null;
    const jobInstance = this.getJobInstanceById(jobIdOrJobPostId);
    const jobId = jobInstance?.id || (jobPost as any)?.job_id || null;

    const disputes = readDisputes();
    const existing = Object.values(disputes).find(
      (d) => d.job_post_id === jobPost.id && (d.status === 'open' || d.status === 'in_review')
    );
    if (existing) return existing;

    const id = crypto.randomUUID();
    const dispute: DemoDispute = {
      id,
      job_post_id: jobPost.id,
      job_id: jobId,
      opened_by_user_id: openedByUserId,
      status: 'open',
      reason,
      assigned_admin_id: null,
      created_at: now,
      updated_at: now,
    };
    disputes[id] = dispute;
    writeDisputes(disputes);

    const events = readDisputeEvents();
    const firstEvent: AdminDisputeEvent = {
      id: crypto.randomUUID(),
      dispute_id: id,
      actor_user_id: openedByUserId,
      event_type: 'status_change',
      message: 'Dispute opened: open',
      created_at: now,
    };
    events[id] = [firstEvent];
    writeDisputeEvents(events);

    const messages = readDisputeMessages();
    const systemMessage: DisputeMessage = {
      id: crypto.randomUUID(),
      dispute_id: id,
      sender_id: null,
      type: 'system',
      content: `Dispute opened (demo). Reason: ${reason}`,
      is_system_message: true,
      created_at: now,
      sender_email: null,
      sender_role: null,
    };
    messages[id] = [systemMessage];
    writeDisputeMessages(messages);

    return dispute;
  },

  getDisputeByJob(jobIdOrJobPostId: string) {
    const jobPost = this.getJobById(jobIdOrJobPostId) || this.getJobPostByJobId(jobIdOrJobPostId);
    if (!jobPost) return null;
    const disputes = Object.values(readDisputes()).filter((d) => d.job_post_id === jobPost.id);
    if (disputes.length === 0) return null;
    disputes.sort((a, b) => {
      const aOpen = a.status === 'open' || a.status === 'in_review';
      const bOpen = b.status === 'open' || b.status === 'in_review';
      if (aOpen !== bOpen) return aOpen ? -1 : 1;
      return (b.created_at || '').localeCompare(a.created_at || '');
    });
    const d = disputes[0];
    return { ...d, title: jobPost.title || 'Dispute' };
  },

  getDisputeById(disputeId: string) {
    const dispute = readDisputes()[disputeId] || null;
    if (!dispute) return null;
    const jobPost = this.getJobById(dispute.job_post_id);
    return {
      ...dispute,
      title: jobPost?.title || 'Dispute',
    };
  },

  getDisputeEvents(disputeId: string) {
    const map = readDisputeEvents();
    return map[disputeId] || [];
  },

  getDisputeMessages(disputeId: string) {
    const map = readDisputeMessages();
    return map[disputeId] || [];
  },

  postDisputeMessage(disputeId: string, sender: { id: string; role?: string; email?: string }, content: string) {
    const now = new Date().toISOString();
    const disputes = readDisputes();
    const dispute = disputes[disputeId];
    if (!dispute) return null;
    if (dispute.status !== 'open' && dispute.status !== 'in_review') return null;

    const message: DisputeMessage = {
      id: crypto.randomUUID(),
      dispute_id: disputeId,
      sender_id: sender.id,
      type: 'text',
      content,
      is_system_message: false,
      created_at: now,
      sender_email: sender.email || null,
      sender_role: sender.role || null,
    };
    const map = readDisputeMessages();
    map[disputeId] = [...(map[disputeId] || []), message];
    writeDisputeMessages(map);

    disputes[disputeId] = { ...dispute, updated_at: now };
    writeDisputes(disputes);

    return message;
  },

  requestDisputeClose(disputeId: string, actor: { id: string }, reason?: string) {
    const now = new Date().toISOString();
    const disputes = readDisputes();
    const dispute = disputes[disputeId];
    if (!dispute) return false;
    if (dispute.status !== 'open' && dispute.status !== 'in_review') return false;

    const events = readDisputeEvents();
    const list = events[disputeId] || [];
    if (dispute.status === 'open') {
      list.push({
        id: crypto.randomUUID(),
        dispute_id: disputeId,
        actor_user_id: actor.id,
        event_type: 'status_change',
        message: 'Status changed: open → in_review (request close)',
        created_at: now,
      });
      dispute.status = 'in_review';
    }
    list.push({
      id: crypto.randomUUID(),
      dispute_id: disputeId,
      actor_user_id: actor.id,
      event_type: 'note',
      message: reason ? `Request close: ${reason}` : 'Request close',
      created_at: now,
    });
    events[disputeId] = list;
    writeDisputeEvents(events);

    const messages = readDisputeMessages();
    const msgs = messages[disputeId] || [];
    msgs.push({
      id: crypto.randomUUID(),
      dispute_id: disputeId,
      sender_id: null,
      type: 'system',
      content: reason ? `User requested close. Reason: ${reason}` : 'User requested close.',
      is_system_message: true,
      created_at: now,
      sender_email: null,
      sender_role: null,
    });
    messages[disputeId] = msgs;
    writeDisputeMessages(messages);

    disputes[disputeId] = { ...dispute, updated_at: now };
    writeDisputes(disputes);
    return true;
  },
};

