import { ReactNode } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { LoadingState } from './components/ui';
import { useAuth } from './contexts';
import type { UserRole } from './contexts/AuthContext';

export function RequireAuth({ children }: { children: ReactNode }) {
  const { user, isLoading } = useAuth();
  const location = useLocation();

  if (isLoading) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-10">
        <LoadingState message="กำลังตรวจสอบสถานะการเข้าสู่ระบบ..." />
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" replace state={{ from: location.pathname }} />;
  }

  return <>{children}</>;
}

export function RequireRole({
  children,
  roles,
  redirectTo,
}: {
  children: ReactNode;
  roles: UserRole[];
  redirectTo?: string;
}) {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-10">
        <LoadingState message="กำลังตรวจสอบสิทธิ์..." />
      </div>
    );
  }

  if (!user) return <Navigate to="/login" replace />;

  if (!roles.includes(user.role)) {
    const fallback =
      redirectTo ||
      (user.role === 'hirer' ? '/hirer/home' : user.role === 'caregiver' ? '/caregiver/jobs/feed' : '/admin/dashboard');
    return <Navigate to={fallback} replace />;
  }

  return <>{children}</>;
}

export function RequireAdmin({ children }: { children: ReactNode }) {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-10">
        <LoadingState message="กำลังตรวจสอบสิทธิ์..." />
      </div>
    );
  }

  if (!user) return <Navigate to="/admin/login" replace />;
  if (user.role !== 'admin') return <Navigate to="/" replace />;

  return <>{children}</>;
}

